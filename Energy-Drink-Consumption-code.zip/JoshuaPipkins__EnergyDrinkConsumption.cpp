#include <iostream>
using namespace std; 

int main() {
int customer = 165000; 

double buyEnergy= 0.15, 
buyCitrus = buyEnergy * 0.58; 
int Energycustomer = customer*buyEnergy;
int Citruscustomer = customer*buyCitrus;

	cout <<"                       Energy Drink Consumption      "<< endl;
	cout<<"_________________________________________________________________________"<< endl <<"\n";
    
		cout << "       We surveyed 16,500 of our customers! Let's see the results!" <<"\n"<<endl;
		
		cout << Energycustomer <<" Customers purchased one or more energy drink(s)per week!" <<"\n"<<endl;
		
		cout << Citruscustomer << " Customers prefered citrus-flavored energy drink(s)"<<"\n"<<endl;
cout<<"_________________________________________________________________________"<<endl;

return 0; 

}